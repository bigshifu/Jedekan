# Jedekan Apps

## Final Project Pemrograman Aplikasi Perangkat Bergerak

## Anggota
1. Muhammad Lamkhil Bashor
2. Ryan Sutawijaya
3. Ersya Nadia Candra
4. Abdurrahman Faiz
6. Yualief Riswanda

## Deskripsi

## Detail Cara Bermain

## Screenshot
