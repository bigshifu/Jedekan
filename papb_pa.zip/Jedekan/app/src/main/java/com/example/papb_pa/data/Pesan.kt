package com.example.papb_pa.data

data class Pesan(
        val id : String?,
        val jeneng : String?,
        val pesan: String?
        )