package com.example.papb_pa.data

data class User(val id : String?, val jeneng : String?)
