package com.example.papb_pa.data

data class getRoom(
    var code : String?,
    var id : String?,
    var jeneng : String?,
    var jumlah : Int?
)

data class storeRoom(
    var code : String?,
    var id : String?,
    var jeneng : String?
)
